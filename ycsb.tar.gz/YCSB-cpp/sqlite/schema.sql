CREATE TABLE IF NOT EXISTS usertable(
    user_id TEXT PRIMARY KEY,
    field0 TEXT,
    field1 TEXT,
    field2 TEXT,
    field3 TEXT,
    field4 TEXT,
    field5 TEXT,
    field6 TEXT,
    field7 TEXT,
    field8 TEXT,
    field9 TEXT
);
